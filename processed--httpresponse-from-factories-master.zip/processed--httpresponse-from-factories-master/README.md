processed--httpresponse-from-factories
======================================

In some cases you would require factory to return only the data that you want. Below I've shown how that can be achieved .
demo here http://code.ciphertrick.com/demo/angularfactories/
tutorial here 
